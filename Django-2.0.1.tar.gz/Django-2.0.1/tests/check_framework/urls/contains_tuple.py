urlpatterns = [
    (r'^tuple/$', lambda x: x),
]
