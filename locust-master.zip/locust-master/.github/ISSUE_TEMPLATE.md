<!-- For general questions about how to use Locust, use either the Slack link provided in the Readme or [ask a question on Stack Overflow](https://stackoverflow.com/questions/ask) tagged Locust.-->


### Description of issue / feature request

TBD

### Expected behavior

TBD

### Actual behavior

TBD

### Environment settings (for bug reports)

- OS:
- Python version:
- Locust version:

### Steps to reproduce (for bug reports)

TBD - [example code appreciated](https://stackoverflow.com/help/mcve)