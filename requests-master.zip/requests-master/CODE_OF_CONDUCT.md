Be cordial or be on your way.

https://www.kennethreitz.org/essays/be-cordial-or-be-on-your-way
